#!/bin/bash
rm -rf model_dir/*
rm -rf log
